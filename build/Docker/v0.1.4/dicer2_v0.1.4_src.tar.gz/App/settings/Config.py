class Config(object):
    ELASTICSEARCH_HOST = "localhost"
    MINIMAL_LINE_LENGTH = 0
    JACCARD_THRESHOLD_VALUE = 0.3
