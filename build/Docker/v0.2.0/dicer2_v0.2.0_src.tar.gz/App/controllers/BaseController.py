from App.controllers.BaseDocumentController import BaseDocumentController


class BaseController(BaseDocumentController):
    """ 继承了所有控制器的基本控制器类 """
    pass
