from App.hooks.ElasticConnectionCheckHook import init_elastic_connection


def init_hook(app):
    # 钩子函数 before_first_request
    @app.before_first_request
    def before_first():
        init_elastic_connection(app)

    # 钩子函数 before_request
    @app.before_request
    def before():
        pass
