class JobError(Exception):
    """ 自定义JobError """

    pass
