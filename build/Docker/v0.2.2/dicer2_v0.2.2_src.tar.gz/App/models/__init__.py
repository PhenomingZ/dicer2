from App.models.ArticleMapping import Article
from App.models.BaseMapping import Base
from App.models.BaseIndexMapping import BaseIndex
from App.models.BaseTaskMapping import BaseTask
from App.models.BaseDocumentMapping import BaseDocument
