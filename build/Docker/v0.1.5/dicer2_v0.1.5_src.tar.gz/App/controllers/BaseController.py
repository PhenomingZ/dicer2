from App.controllers.BaseDocumentController import BaseDocumentController


class BaseController(BaseDocumentController):
    pass
